<?php
/**
 * @file
 * bootstrap-search-form-wrapper.func.php
 */

/**
 * Theme function implementation for bootstrap_search_form_wrapper.
 */
function bootstrap_bootstrap_search_form_wrapper($variables) {
  $output = '<div class="input-group">';

//added 07282015 by Henry: Adds label to search form block
    $output .= '<label for="edit-search-block-form--2" class="element-invisible">Search Smokefree 60 Plus</label>';

  $output .= $variables['element']['#children'];
  $output .= '<span class="input-group-btn">';
  $output .= '<button type="submit" class="btn btn-default">';
  // We can be sure that the font icons exist in CDN.
  if (theme_get_setting('bootstrap_cdn')) {
    //$output .= _bootstrap_icon('search');
	  $output .= '<img class="icon glyphicon glyphicon-search" src="/sites/all/themes/sixtyplus/css/image-icons/32/search.png" alt="search" aria-hidden="true"/>';
	//11-27-2015 Added text to comply with Section 508 -- wave
	$output .= '<span class="element-invisible">Search Button</span>';
  }
  else {
    $output .= t('Search');
  }
  $output .= '</button>';
  $output .= '</span>';
  $output .= '</div>';
  return $output;
}
